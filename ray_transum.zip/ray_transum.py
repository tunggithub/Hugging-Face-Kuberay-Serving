from starlette.requests import Request
from typing import Dict

import ray
from ray import serve
from ray.serve.handle import DeploymentHandle

from transformers import pipeline


@serve.deployment
class Translator:
    def __init__(self):
        self.language = 'french'
        self.model = pipeline(
            "translation_en_to_fr",
            model="t5-small",
            framework="pt",
            device="cuda"
        )

    def translate(self, text: str) -> str:
        model_output = self.model(text)
        return model_output[0]["translation_text"]

    def reconfigure(self, config: Dict):
        self.language = config.get("language", "french")
        lang = self.language.lower()
        if lang == "french":
            task = "translation_en_to_fr"
        elif lang == "german":
            task = "translation_en_to_de"
        elif lang == "romanian":
            task = "translation_en_to_ro"
        else:
            return  # giữ nguyên

        self.model = pipeline(task, model="t5-small", framework="pt", device="cuda")


@serve.deployment
class Summarizer:
    def __init__(self, translator: DeploymentHandle):
        self.translator = translator
        self.model = pipeline(
            "summarization",
            model="t5-small",
            framework="pt",
            device="cuda"
        )
        self.min_length = 5
        self.max_length = 15

    def summarize(self, text: str) -> str:
        output = self.model(text, min_length=self.min_length, max_length=self.max_length)
        return output[0]["summary_text"]

    async def __call__(self, http_request: Request) -> str:
        english_text: str = await http_request.json()
        summary = self.summarize(english_text)
        # Gọi async translate qua handle
        translation = await self.translator.translate.remote(summary)
        return translation

    def reconfigure(self, config: Dict):
        self.min_length = config.get('min_length', 5)
        self.max_length = config.get('max_length', 15)


# Triển khai
app = Summarizer.bind(Translator.bind())
